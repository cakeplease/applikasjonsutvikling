package ntnu.katarzsz.oving4

import androidx.lifecycle.ViewModel

class MyViewModel : ViewModel() {
    val games: ArrayList<Game> = ArrayList()
}